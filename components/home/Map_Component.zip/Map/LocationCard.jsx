import React from "react";

const LocationCard = () => {
  return <div>LocationCard</div>;
};

export default LocationCard;
